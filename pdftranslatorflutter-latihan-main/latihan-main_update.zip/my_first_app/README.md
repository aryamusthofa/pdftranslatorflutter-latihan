# My First App 🚀

A premium Cross-Platform Flutter application built with a modern Glassmorphism UI, robust local persistence, and advanced features. This project demonstrates a complete mobile/desktop application lifecycle, from basic layouts to advanced state management and platform-specific configurations.

---

## 🇬🇧 English | 🇮🇩 [Bahasa Indonesia](./test/README.md)

---

## 🌟 Key Features

-   **Premium Glassmorphism UI**: High-fidelity design with vibrant gradients, blurred cards, and modern typography.
-   **Local Persistence (Sembast)**: High-performance NoSQL local database for storing user data, settings, and items.
-   **Live API Integration**: Real-time photo gallery fetching data from OpenSource APIs (JSONPlaceholder).
-   **Solid Authentication**: Secure login and registration system with session persistence.
-   **Interactive Lamp Simulation**: Advanced UI demonstration with glowing effects and real-time state persistence.
-   **Profile Management**: Editable display name, bio, and 1:1 cropped profile photo upload.
-   **Global State Management**: Powered by `Provider` for synchronized data across all pages.
-   **Multi-language Support**: Seamless switching between Indonesian and English.

## 🛠 Tech Stack

-   **Framework**: [Flutter](https://flutter.dev/) (Material 3)
-   **State Management**: [Provider](https://pub.dev/packages/provider)
-   **Local Database**: [Sembast](https://pub.dev/packages/sembast) (NoSQL)
-   **Security/Session**: [SharedPreferences](https://pub.dev/packages/shared_preferences)
-   **Animations**: [Flutter Staggered Animations](https://pub.dev/packages/flutter_staggered_animations)
-   **Image Handling**: `image_picker` & `crop_your_image`

## 🚀 Getting Started

### Prerequisites
- Flutter SDK (Latest Stable)
- Dart SDK
- (For WSL/Linux) Systemd & XDG Desktop Portal

### Installation
1.  Clone the repository:
    ```bash
    git clone https://github.com/[your-username]/my_first_app.git
    cd my_first_app
    ```
2.  Install dependencies:
    ```bash
    flutter pub get
    ```
3.  Run the application:
    ```bash
    flutter run
    ```

### 🐧 WSL/Linux Special Note
If you are running this app on **WSL Fedora/Linux**, ensure `systemd` is enabled in your `/etc/wsl.conf` to support the file picker for profile photos:
```ini
[boot]
systemd=true
```

## 📈 Development Progress (Phases)

-   **Phase 1**: Core Layouts & Local Persistence (Sembast DB).
-   **Phase 2**: Networking & API integration for the Gallery.
-   **Phase 3**: Authentication system & Account Guard.
-   **Phase 4**: Advanced UI, Glassmorphism & Animations.
-   **Phase 5**: Personalization (Profile Edit, Settings & Search).
-   **Phase 6**: Profile Photo Upload (Interactive 1:1 Cropping).

---

*Developed with ❤️ by Antigravity (Powered by Google DeepMind)*
