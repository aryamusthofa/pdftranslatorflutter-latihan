# My First App 🚀 (Indonesian Version)

## 🇮🇩 Bahasa Indonesia | 🇬🇧 [English](../README.md)

---

## 🇮🇩 Ringkasan Project
Proyek ini mendemonstrasikan siklus hidup aplikasi mobile/desktop lengkap, mulai dari tata letak dasar hingga manajemen state tingkat lanjut dan konfigurasi spesifik platform.

## 🌟 Fitur Utama
-   **UI Glassmorphism Premium**: Desain artistik dengan gradien vibrant, kartu blur, dan tipografi modern.
-   **Penyimpanan Lokal (Sembast)**: Database NoSQL lokal berkinerja tinggi untuk menyimpan data pengguna, pengaturan, dan item.
-   **Integrasi API Live**: Galeri foto real-time yang mengambil data dari API OpenSource (JSONPlaceholder).
-   **Autentikasi Solid**: Sistem login dan registrasi yang aman dengan penyimpanan sesi (session persistence).
-   **Simulasi Lampu Interaktif**: Demonstrasi UI tingkat lanjut dengan efek cahaya glowing dan penyimpanan status real-time.
-   **Manajemen Profil**: Edit nama tampilan, bio, dan unggah foto profil dengan fitur potong (crop) 1:1.
-   **State Management Global**: Didukung oleh `Provider` untuk sinkronisasi data di semua halaman.
-   **Dukungan Multi-bahasa**: Perpindahan mulus antara Bahasa Indonesia dan Inggris.

## 🛠 Tech Stack
-   **Framework**: [Flutter](https://flutter.dev/) (Material 3)
-   **State Management**: [Provider](https://pub.dev/packages/provider)
-   **Local Database**: [Sembast](https://pub.dev/packages/sembast) (NoSQL)
-   **Security/Session**: [SharedPreferences](https://pub.dev/packages/shared_preferences)
-   **Animations**: [Flutter Staggered Animations](https://pub.dev/packages/flutter_staggered_animations)
-   **Image Handling**: `image_picker` & `crop_your_image`

## 🚀 Cara Menjalankan
1.  Pastikan Flutter SDK sudah terinstall.
2.  Jalankan perintah ini di terminal:
    ```bash
    flutter pub get
    flutter run
    ```

### 🐧 Catatan Khusus WSL/Linux
Jika menjalankan aplikasi ini di **WSL Fedora/Linux**, pastikan `systemd` aktif di `/etc/wsl.conf` untuk mendukung pemilihan foto profil:
```ini
[boot]
systemd=true
```

## 📈 Progres Pengembangan
-   **Phase 1**: Tata Letak Inti & Database Lokal (Sembast).
-   **Phase 2**: Networking & Integrasi API Galeri.
-   **Phase 3**: Sistem Autentikasi & Guard Akun.
-   **Phase 4**: UI Lanjutan, Glassmorphism & Animasi.
-   **Phase 5**: Personalisasi (Edit Profil, Settings & Search).
-   **Phase 6**: Upload Foto Profil (Crop Interaktif 1:1).

---

*Dikembangkan dengan ❤️ oleh Antigravity (Powered by Google DeepMind)*
