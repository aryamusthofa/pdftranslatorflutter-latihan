#!/bin/bash
mkdir -p ~/.runtime && chmod 700 ~/.runtime
export XDG_RUNTIME_DIR=~/.runtime
dbus-run-session -- sh -c "echo \$DBUS_SESSION_BUS_ADDRESS > ~/.dbus_session_addr; /usr/libexec/xdg-desktop-portal-gtk & /usr/libexec/xdg-desktop-portal & sleep infinity"
