//main_page.dart
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:translator/translator.dart';

import 'login_page.dart';
import 'profile_page.dart';
import 'grid_page.dart';

class MainPage extends StatefulWidget {
  final String username;
  const MainPage({super.key, required this.username});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int currentIndex = 0;
  late final List<Widget> pages;

  @override
  void initState() {
    super.initState();
    pages = [
      const PdfTranslatorPage(), 
      const LayoutDemoPage(),    
      const GridDemoPage(),  
      ProfilePage(username: widget.username),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(widget.username),
              accountEmail: const Text('user@app.com'),
              currentAccountPicture: const CircleAvatar(
                child: Icon(Icons.person),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.translate),
              title: const Text('Terjemah PDF'),
              onTap: () {
                setState(() => currentIndex = 0);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Home'),
              onTap: () {
                setState(() => currentIndex = 1);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text('Riwayat'),
              onTap: () {
                setState(() => currentIndex = 2);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text('Profil'),
              onTap: () {
                setState(() => currentIndex = 3);
                Navigator.pop(context);
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                );
              },
            ),
          ],
        ),
      ),
      body: pages[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        type: BottomNavigationBarType.fixed, 
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() => currentIndex = index);
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.translate), label: 'Terjemah'),
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'Riwayat'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}


class LayoutDemoPage extends StatelessWidget {
  const LayoutDemoPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> items = List.generate(20, (index) => "Item Data Ke-${index + 1}");

    return Scaffold(
      appBar: AppBar(
        title: const Text('Praktek ListView Flutter'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '1. ListView Default (Statis)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const Text('Gunakan jika data sedikit dan sudah pasti.'),
            const SizedBox(height: 10),
            Container(
              height: 150,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.indigo),
                borderRadius: BorderRadius.circular(8),
              ),
              child: ListView(
                children: const [
                  ListTile(
                    leading: Icon(Icons.info, color: Colors.blue),
                    title: Text('Informasi Aplikasi'),
                  ),
                  ListTile(
                    leading: Icon(Icons.help, color: Colors.orange),
                    title: Text('Pusat Bantuan'),
                  ),
                  ListTile(
                    leading: Icon(Icons.settings, color: Colors.grey),
                    title: Text('Pengaturan Umum'),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            const Text(
              '2. ListView.builder (Dinamis)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const Text('Efisien untuk data banyak (Lazy Loading).'),
            const SizedBox(height: 10),
            Container(
              height: 200,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.green),
                borderRadius: BorderRadius.circular(8),
              ),
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: CircleAvatar(child: Text('${index + 1}')),
                    title: Text(items[index]),
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Anda menekan ${items[index]}')),
                      );
                    },
                  );
                },
              ),
            ),

            const SizedBox(height: 30),

            const Text(
              '3. ListView.separated (Dengan Divider)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const Text('Tampilan lebih rapi dengan garis pemisah.'),
            const SizedBox(height: 10),
            Container(
              height: 200,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.red),
                borderRadius: BorderRadius.circular(8),
              ),
              child: ListView.separated(
                itemCount: 5, 
                separatorBuilder: (context, index) => const Divider(
                  color: Colors.red,
                  thickness: 1,
                  indent: 15,
                  endIndent: 15,
                ),
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: const Icon(Icons.history),
                    title: Text('Riwayat Transaksi #00${index + 1}'),
                    trailing: const Text('Sukses', style: TextStyle(color: Colors.green)),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PdfTranslatorPage extends StatefulWidget {
  const PdfTranslatorPage({super.key});

  @override
  State<PdfTranslatorPage> createState() => _PdfTranslatorPageState();
}

class _PdfTranslatorPageState extends State<PdfTranslatorPage> {
  String _translatedText = '';
  String _extractedText = ''; // 💾 Simpan text asli dari PDF
  int _totalDetectedCharacters = 0; // 📊 Total karakter yang terdeteksi
  bool _isLoading = false;
  final GoogleTranslator _translator = GoogleTranslator();
  
  // 🎚️ Kontrol limit karakter
  TextEditingController _characterLimitController = TextEditingController(text: '15000');
  
  // ⚠️ HARD LIMIT untuk API safety (Google Translator max ~15000 char per request)
  static const int MAX_SAFE_CHARACTER_LIMIT = 15000;
  static const int WARNING_THRESHOLD = 15000;

  // Map bahasa support: code -> nama
  final Map<String, String> languages = {
    'en': '🇬🇧 English',
    'id': '🇮🇩 Indonesian',
    'es': '🇪🇸 Spanish',
    'fr': '🇫🇷 French',
    'de': '🇩🇪 German',
    'pt': '🇵🇹 Portuguese',
    'nl': '🇳🇱 Dutch',
    'ru': '🇷🇺 Russian',
    'zh': '🇨🇳 Chinese',
    'ja': '🇯🇵 Japanese',
    'ar': '🇸🇦 Arabic',
    'th': '🇹🇭 Thai',
    'vi': '🇻🇳 Vietnamese',
    'hi': '🇮🇳 Hindi',
    'ko': '🇰🇷 Korean',
    'tr': '🇹🇷 Turkish',
    'pl': '🇵🇱 Polish',
  };

  late String _sourceLanguage = 'en';
  late String _targetLanguage = 'id';

  @override
  void initState() {
    super.initState();
    _sourceLanguage = 'en';
    _targetLanguage = 'id';
  }

  @override
  void dispose() {
    _characterLimitController.dispose();
    super.dispose();
  }

  // 🔄 Method untuk re-translate text yang sudah di-extract
  Future<void> _retranslateText() async {
    if (_extractedText.isEmpty) return;
    
    if (!mounted) return;
    setState(() {
      _isLoading = true;
    });

    try {
      int userLimit = int.tryParse(_characterLimitController.text) ?? 5000;
      
      // ⚠️ Enforce hardcap untuk safety API
      int safeLimitToUse = min(userLimit, MAX_SAFE_CHARACTER_LIMIT);
      
      String textToTranslate = _extractedText;
      
      // 🎚️ Apply limit yang sudah di-enforce
      if (textToTranslate.length > safeLimitToUse) {
        textToTranslate = textToTranslate.substring(0, safeLimitToUse);
      }

      var translation = await _translator.translate(
        textToTranslate,
        from: _sourceLanguage,
        to: _targetLanguage
      );

      if (!mounted) return;
      setState(() {
        _translatedText = translation.text;
      });
    } catch (e) {
      if (!mounted) return;
      String errorMsg = 'Terjadi kesalahan: ';
      
      // 🔍 Parse error yang lebih spesifik
      if (e.toString().contains('400')) {
        errorMsg += 'Request terlalu besar atau format salah. Coba kurangi batas karakter.';
      } else if (e.toString().contains('Read') || e.toString().contains('timeout')) {
        errorMsg += 'Koneksi timeout. Coba kurangi batas karakter atau cek internet.';
      } else if (e.toString().contains('Broken')) {
        errorMsg += 'Koneksi terputus. Coba lagi atau kurangi batas karakter.';
      } else {
        errorMsg += e.toString();
      }
      
      setState(() {
        _translatedText = errorMsg;
      });
    } finally {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _pickAndTranslatePdf() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _translatedText = 'Membaca dan menerjemahkan PDF...';
    });

    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        withData: true, 
      );

      if (!mounted) return;

      if (result != null) {
        List<int>? bytes;

        if (kIsWeb) {
          bytes = result.files.single.bytes;
        } else {
          if (result.files.single.path != null) {
            File file = File(result.files.single.path!);
            bytes = await file.readAsBytes();
          }
        }

        if (bytes == null) {
          if (!mounted) return;
          setState(() {
            _translatedText = 'Gagal memuat file PDF.';
            _isLoading = false;
          });
          return;
        }

        final PdfDocument document = PdfDocument(inputBytes: bytes);
        final String extractedText = PdfTextExtractor(document).extractText();
        document.dispose();

        if (extractedText.trim().isEmpty) {
          if (!mounted) return;
          setState(() {
            _translatedText = 'Tidak ada teks yang dapat diekstrak. Mungkin PDF ini berisi gambar hasil scan.';
            _isLoading = false;
          });
          return;
        }

        String cleanText = extractedText.replaceAll('\r\n', '\n');
        cleanText = cleanText.replaceAll(RegExp(r'(?<!\n)\n(?!\n)'), ' ');
        cleanText = cleanText.replaceAll(RegExp(r'[ \t]+'), ' ').trim();

        // 💾 Simpan extracted text PENUH untuk re-translate nanti (tanpa limit)
        _extractedText = cleanText;
        
        // 📊 Simpan jumlah character yang terdeteksi
        int detectedChars = cleanText.length;

        // ⚠️ Apply hardcap limit untuk safety API
        String textToTranslate = cleanText;
        if (textToTranslate.length > MAX_SAFE_CHARACTER_LIMIT) {
          textToTranslate = textToTranslate.substring(0, MAX_SAFE_CHARACTER_LIMIT);
        }

        var translation = await _translator.translate(
          textToTranslate, 
          from: _sourceLanguage, 
          to: _targetLanguage
        );

        if (!mounted) return;
        setState(() {
          _translatedText = translation.text;
          _totalDetectedCharacters = detectedChars;
        });
      } else {
        if (!mounted) return;
        setState(() {
          _translatedText = '';
          _extractedText = '';
          _totalDetectedCharacters = 0;
        });
      }
    } catch (e) {
      if (!mounted) return;
      String errorMsg = 'Terjadi kesalahan: ';
      
      // 🔍 Parse error yang lebih spesifik
      if (e.toString().contains('400')) {
        errorMsg += 'Request terlalu besar atau format salah. Kurangi batas karakter.';
      } else if (e.toString().contains('Read') || e.toString().contains('timeout')) {
        errorMsg += 'Koneksi timeout. Cek internet atau kurangi batas karakter.';
      } else if (e.toString().contains('Broken')) {
        errorMsg += 'Koneksi terputus. Coba lagi atau kurangi batas karakter.';
      } else {
        errorMsg += e.toString();
      }
      
      setState(() {
        _translatedText = errorMsg;
      });
    } finally {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Penerjemah PDF Multi-Bahasa'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Language Selection Row
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Dari:',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 5),
                      DropdownButton<String>(
                        isExpanded: true,
                        value: _sourceLanguage,
                        items: languages.entries
                            .map((e) => DropdownMenuItem<String>(
                              value: e.key,
                              child: Text(e.value),
                            ))
                            .toList(),
                        onChanged: (value) {
                          if (!mounted) return;
                          setState(() {
                            _sourceLanguage = value!;
                          });
                          // 🔄 Auto re-translate ketika bahasa sumber berubah
                          if (_extractedText.isNotEmpty) {
                            _retranslateText();
                          }
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Ke:',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 5),
                      DropdownButton<String>(
                        isExpanded: true,
                        value: _targetLanguage,
                        items: languages.entries
                            .map((e) => DropdownMenuItem<String>(
                              value: e.key,
                              child: Text(e.value),
                            ))
                            .toList(),
                        onChanged: (value) {
                          if (!mounted) return;
                          setState(() {
                            _targetLanguage = value!;
                          });
                          // 🔄 Auto re-translate ketika bahasa target berubah
                          if (_extractedText.isNotEmpty) {
                            _retranslateText();
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // 🎚️ Character Limit Setting
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Batas Karakter untuk Terjemahan:',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _characterLimitController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: 'Masukkan jumlah karakter (maks: $MAX_SAFE_CHARACTER_LIMIT)',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          helperText: '⚠️ Maksimal $MAX_SAFE_CHARACTER_LIMIT untuk stabilitas API',
                          helperStyle: const TextStyle(fontSize: 10, color: Colors.orange),
                        ),
                        onChanged: (value) {
                          int? parsed = int.tryParse(value);
                          if (parsed != null && parsed > MAX_SAFE_CHARACTER_LIMIT) {
                            // Auto-limit ke max safe
                            _characterLimitController.text = MAX_SAFE_CHARACTER_LIMIT.toString();
                          }
                          // Re-translate jika ada teks ter-extract
                          if (_extractedText.isNotEmpty && !_isLoading) {
                            Future.delayed(const Duration(milliseconds: 500), () {
                              if (_extractedText.isNotEmpty) {
                                _retranslateText();
                              }
                            });
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () {
                        _characterLimitController.text = MAX_SAFE_CHARACTER_LIMIT.toString();
                        if (_extractedText.isNotEmpty && !_isLoading) {
                          _retranslateText();
                        }
                      },
                      child: const Text('Reset'),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // 📊 Info text yang terdeteksi
                if (_totalDetectedCharacters > 0)
                  Text(
                    '📊 Terdeteksi: $_totalDetectedCharacters karakter | '
                    'Akan diterjemahkan: ${min(_totalDetectedCharacters, MAX_SAFE_CHARACTER_LIMIT)} karakter',
                    style: TextStyle(fontSize: 11, color: Colors.grey[700]),
                  ),
                // ⚠️ Warning jika terlalu banyak karakter
                if (_totalDetectedCharacters > MAX_SAFE_CHARACTER_LIMIT)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.orange[50],
                        border: Border.all(color: Colors.orange),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.warning, color: Colors.orange, size: 16),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'PDF memiliki ${_totalDetectedCharacters - MAX_SAFE_CHARACTER_LIMIT} karakter di atas limit aman API. '
                              'Hanya ${MAX_SAFE_CHARACTER_LIMIT} karakter pertama yang akan diterjemahkan.',
                              style: const TextStyle(fontSize: 10, color: Colors.orange),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _pickAndTranslatePdf,
              icon: const Icon(Icons.picture_as_pdf),
              label: Text('Pilih File PDF (${languages[_sourceLanguage]})'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            const SizedBox(height: 20),
            
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    'Hasil Terjemahan ke ${languages[_targetLanguage]}:',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.copy, color: Colors.blue),
                  tooltip: 'Salin Teks',
                  onPressed: _translatedText.isNotEmpty && !_isLoading
                      ? () async {
                          await Clipboard.setData(
                            ClipboardData(text: _translatedText)
                          );
                          if (mounted && context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Teks berhasil disalin!'),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          }
                        }
                      : null,
                ),
              ],
            ),
            
            const SizedBox(height: 5),
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.grey.shade50,
                ),
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : SingleChildScrollView(
                        child: Text(
                          _translatedText.isEmpty
                              ? 'Teks hasil terjemahan akan muncul di sini.'
                              : _translatedText,
                          style: const TextStyle(fontSize: 16, height: 1.5),
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}